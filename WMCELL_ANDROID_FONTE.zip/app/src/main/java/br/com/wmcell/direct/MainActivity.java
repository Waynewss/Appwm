package br.com.wmcell.direct;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/** Native Android shell for the locally bundled WMCELL DIRECT UI. */
public final class MainActivity extends Activity {
    private WebView webView;
    private static final String HOME = "file:///android_asset/index.html";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11, 11, 14));
        getWindow().setNavigationBarColor(Color.rgb(11, 11, 14));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11, 11, 14));
        webView.setWebChromeClient(new WebChromeClient());
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return intercept(request.getUrl());
            }
            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return intercept(Uri.parse(url));
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "WMCELLAndroid");
        setContentView(webView);
        webView.loadUrl(HOME);
    }

    // Never navigate to remote web pages inside the WebView with a JavaScript bridge.
    private boolean intercept(Uri uri) {
        if (uri == null) return true;
        if ("file".equalsIgnoreCase(uri.getScheme())
                && uri.getPath() != null && uri.getPath().startsWith("/android_asset/")) {
            return false;
        }
        if ("https".equalsIgnoreCase(uri.getScheme())) {
            String host = uri.getHost();
            if ("wa.me".equalsIgnoreCase(host) || "api.whatsapp.com".equalsIgnoreCase(host)) {
                openExternal(uri);
            }
        }
        // Non-local/unknown URLs are not allowed to load in this WebView.
        return true;
    }

    private void openExternal(Uri uri) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Nenhum aplicativo conseguiu abrir o link.", Toast.LENGTH_LONG).show();
        }
    }

    private void openChat(String number, String message, String type) {
        if (number == null || !number.matches("[0-9]{8,15}")) {
            Toast.makeText(this, "Número inválido.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (message == null) message = "";
        final String text = message.length() > 1500 ? message.substring(0, 1500) : message;
        final String query = "phone=" + number + (text.isEmpty() ? "" : "&text=" + Uri.encode(text));
        final String pkg = "business".equals(type) ? "com.whatsapp.w4b" : "com.whatsapp";
        try {
            // Explicit package ensures Business and Normal do not get mixed up.
            Intent target = new Intent(Intent.ACTION_VIEW, Uri.parse("whatsapp://send?" + query));
            target.setPackage(pkg);
            startActivity(target);
        } catch (ActivityNotFoundException ex) {
            Toast.makeText(this,
                    "WhatsApp selecionado indisponível; abrindo link universal.",
                    Toast.LENGTH_LONG).show();
            Uri fallback = Uri.parse("https://wa.me/" + number
                    + (text.isEmpty() ? "" : "?text=" + Uri.encode(text)));
            openExternal(fallback);
        } catch (SecurityException ex) {
            Toast.makeText(this, "Não foi possível abrir o WhatsApp.", Toast.LENGTH_LONG).show();
        }
    }

    private final class AndroidBridge {
        @JavascriptInterface
        public void openConversation(String number, String message, String type) {
            runOnUiThread(() -> openChat(number, message, type));
        }
        @JavascriptInterface
        public void copyText(String value) {
            if (value == null || value.length() > 10000) return;
            runOnUiThread(() -> {
                ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cb != null) cb.setPrimaryClip(ClipData.newPlainText("WMCELL DIRECT", value));
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("WMCELLAndroid");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
